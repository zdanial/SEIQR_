import numpy as np
import plotly.graph_objects as go
import streamlit as st


def expenses_by_income(income):
    """
    model of linear fit of annual household expenses by household pre-tax income based on 2019 BLS survey 
    """
    
    Y_INTERCEPT = 25000
    SLOPE = 0.47
    
    return SLOPE * income + Y_INTERCEPT

def balance_step(debt, invested, income, expenses, debt_interest_rate, RoI):
    """
    This model considers income and debt, 
    with no starting assets but with the ability to invest available cash:
    """

    # Annually compounded interest and returns (for consistency, process both first)
    debt = debt * (1 + debt_interest_rate)
    invested = invested * (1 + RoI)
    
    cash = income - expenses
    
    if cash > debt:
        # fully pay off debt
        cash = cash-debt
        debt = 0
    else:
        # pay off as much debt as possible - and if cash is negative, adds to debt
        debt = debt - cash
        cash = 0
        
    # remaining cash gets invested
    invested += cash
    
    # Assume investments are not liquid
    
    return debt, invested  



#import streamlit_analytics
#streamlit_analytics.start_tracking()

NICOLES_DEFAULT_INCOME = 48500
LAURENS_DEFAULT_INCOME = 155600

FEDERAL_STUDENT_LOANS_RATE_2021 = 3.73 # https://www.cbsnews.com/news/student-loans-biden-more-expensive-interest-rates/#:~:text=For%20borrowers%20taking%20out%20new,%25%2C%20up%20from%205.28%25.
FEDERAL_STUDENT_LOANS_RATE_2022 = 4.99

INTEREST_SAVINGS = 0.08 # percent 
ROR_STOCKS = 10.0 # percent
WEEKS_PER_YEAR = 52

INHERITANCE_DEFAULT_NICOLE = 35000
INHERITANCE_DEFAULT_LAUREN = 100000

NICOLE_AMT_BORROWED_DEFAULT = 23400
LAUREN_AMT_BORROWED_DEFAULT = 16000


MAX_INHERITANCE = 200000
MAX_INCOME = 200000
MAX_ROR = 20.0
MAX_AMT_BORROWED = 100000


st.title('The Racial Wealth Gap and Your Household Finances')

st.markdown(""" Building on previous work with [The Council of the District of Columbia's Office of Racial Equity (CORE)](https://www.dcracialequity.org/) to examine the racial wealth gap in Washington, D.C., MITRE has developed a household finance model to learn more about how racial inequity impacts wealth and to help users answer questions about the wealth gap.""")
st.markdown(""" We know that the median net worth of a white household is 81 times that of a Black household in D.C.<sup>1</sup> While community and cultural assets play a critical role in supporting Black households in D.C., this wealth disparity leads to an uneven financial foundation with wide-ranging and long-lasting impacts. Some questions this model seeks to help answer include: """, unsafe_allow_html=True)

cols = st.columns([0.1, 0.8, 0.1])
with cols[1]:
    st.markdown("""
    - What financial, social, and historical factors led to this racial gap in net worth?  
    - Is the gap widening or shrinking?  
    - How would different financial policies affect the gap? 
    """)

st.markdown("""
In a previously published report ([The Racial Wealth Gap in Washington, D.C.](https://sjp.mitre.org/resources/MITRE-DC-Racial-Wealth-Gap-Study.pdf)), we mapped a wide range of factors that influence wealth building, and provided context from research on the historical oppression, ongoing policies, and inherited inequity that contribute to the racial wealth gap. The report resulted in several follow-on questions, including: """)

cols = st.columns([0.1, 0.8, 0.1])
with cols[1]:
    st.markdown("""
    - How do factors that influence wealth building impact residents and households?  
    - What proposed interventions may influence the bottom line for residents? 
    """)
st.markdown("""
**On this page, we walk through a simplified household finances dynamic model with a focus on how racial inequity translates into the wealth trajectories of two residents, representing the median conditions of a Black D.C. resident and a White D.C. resident.** 
This model can help us understand the dynamics of the racial wealth gap, and in conjunction with community design can support evaluating the financial impact of proposed policies and interventions.""")


st.markdown("""
The term “dynamics” refers to the study of things in motion—in other words, how they change over time. Bringing a dynamic perspective to studying the racial wealth gap means trying to understand its history and future, in addition to its current state. Using a dynamic perspective rather than a static perspective also helps us to look at structures and causes, examining what influences the wealth gap and how. This model provides a way to understand the dynamics of the racial wealth gap by projecting household finances forward in time, assessing whether the gap grows or shrinks when various contributors to the wealth gap are adjusted. Though factors such as income, expenses, and interest rates change over time in the real world, for the purposes of this model these factors are held constant to simplify the model and understand general trends.""")

st.markdown("""
This page focuses on factors that impact household finances and the racial wealth gap and uses two fictional personas: Nicole (a Black D.C. resident) and Lauren (a White D.C. resident), who both grew up in and live in D.C. The page is broken up into sections, each of which discusses and models one of these factors. Nicole and Lauren have been assigned the median values of several conditions impacting household wealth for DC residents of their respective races and are used as demonstrative examples throughout. Follow along below to learn more about the factors that influence the wealth trajectories of these two women using the interactive charts, which project changes in wealth over a 20-year period.  To see the cumulative effects of income (in the “Work Compensation” section) and expenses (in the “Cost of Living” section), the values for these two sections carry forward throughout the graphs in the other sections. To see the individual effects of employment security, inherited wealth, return from investments, and interest from debt, click the box next to “equalize Lauren and Nicole’s...” within each section. The final graph displays the cumulative effects from the values inputted in all sections.   
""")


t0 = 2000
tf = 2020
t = np.arange(t0, tf, 1)


# st.markdown('<style>header {visibility: hidden;height: 0%;}</style>', unsafe_allow_html=True)

# SECTION: Work Compensation
st.subheader('Work Compensation')

st.markdown("""
Differences in work compensation for wage and salary workers throughout their career contribute to differences in wealth over the course of workers’ lifetimes. Differences in the most common occupation for different racial groups are the product of various factors, including barriers to education access, differences in social capital, and hiring discrimination. A higher salary occupation increases income, which in turn increases an individual’s access to other resources, such as education, healthcare, and training. A higher salary also increases an individual’s ability to invest in other wealth building feedback loops. Even in the same occupational categories, there are disparities in the average salary for Black employees compared to White employees.<sup>2</sup> In addition to differences in salary, many lower-wage occupations have limited employer-provided benefits, which offer financial resilience, support workforce readiness, and help build personal assets and wealth, such as retirement matching programs, company stock options, tuition assistance, and health insurance. 
""", unsafe_allow_html=True)
st.markdown("""
<b>Nicole works as a cashier (the most common occupation for Black residents in D.C<sup>3</sup>) while Lauren works as a lawyer (the most common occupation for White residents in D.C<sup>4</sup>). If Nicole’s annual salary as a cashier is \$48,487 (the median income for Black households in 2019), and Lauren’s annual salary working as a lawyer is \$155,562 (the median income for White households in 2019<sup>5</sup>), and they start out with equal wealth at age 20, the interactive graph below shows how their wealth will grow over time. Use the sliders to see the impact of changing Nicole and Lauren’s salaries. The graph below does not include factors beyond Nicole and Lauren’s annual salary. Later graphs will include the cumulative effects of cost of living and salary.</b>
""", unsafe_allow_html=True)

    
cols = st.columns(2)
with cols[0]:
    income1 = st.slider("Nicole's Income", 0, MAX_INCOME, NICOLES_DEFAULT_INCOME, 100, format='$%.2f', key='income11')
with cols[1]:
    income2 = st.slider("Lauren's Income", 0, MAX_INCOME, LAURENS_DEFAULT_INCOME, 100, format='$%.2f', key='income21')
st.button("Reset to original values", key='m1')

income = income1
income_difference = income2 - income1
y1 = income1*(t-t0)
y2 = income2*(t-t0)

plot = go.Figure([go.Scatter(x=t, y=y1, name = "Nicole"), go.Scatter(x=t, y=y2, name = "Lauren")])
plot.update_yaxes(rangemode="tozero")

st.plotly_chart(plot)


st.markdown(f"After 10 years, Lauren will have earned \${y2[-1]:,.2f} and Nicole will have earned \${y1[-1]:,.2f}.  Lauren’s total earnings will be {y2[-1]/y1[-1]:.2f}x times that of Nicole.")

cols = st.columns(3)
with cols[0]:
    st.metric(f'Starting Net Worth Difference ({str(int(t0))})', f'${y2[0] - y1[0]:,.2f}')
with cols[1]:
    st.metric(f'Ending Net Worth Difference ({str(int(tf))})', f'${y2[-1] - y1[-1]:,.2f}')
with cols[2]:
    st.metric(f'Ending Net Worth Multiple ({str(int(tf))})', f'{y2[-1]/y1[-1]:.2f}x')




st.markdown('<br> <br> <br>', unsafe_allow_html=True)



# SECTION: Cost of Living
st.subheader('Cost of Living')

st.markdown("""
Cost of living expenses include costs such as housing, transportation, food, healthcare, education, clothing, and childcare. Housing costs accounted for 37.7\% of the average DC area household income from 2019-2020.<sup>6</sup>  Most D.C. residents rent their home, but gentrification (including external investments and new building projects) has increased property taxes in the city. In D.C., 58\% of Black families own their home compared to 78\% of White families7. Black D.C. households on average have a lower income than White DC residents, making rent a larger portion of their household income, limiting income available to build wealth. Increasing rent costs affect many Black D.C. residents; 20\% of residents in predominantly Black Wards 7 and 8 indicated they would most likely move in the next three years due to high rent prices.<sup>8</sup> 
""", unsafe_allow_html=True)

st.markdown("""
<b>Based on 2019 data from the U.S. Bureau of Labor Statistics, U.S. households spend about \$25,000 + 47\% of their pre-tax income on living expenses. Based on their respective salaries alone, this relationship between living expenses and income suggests Nicole’s cost of living is ~\$47,560 annually (which is nearly her total annual income) and Lauren’s cost of living is projected to be ~\$97,850. Due to their salary differential, Lauren spends a smaller proportion of her income on living expenses. Use the sliders to see the impact of increasing or decreasing the cost of living expenses for the two women.</b>
""", unsafe_allow_html=True)
# income_checkbox = st.checkbox("Equalize Lauren and Nicole's Income")
# if income_checkbox:
#     nicole_income = LAURENS_DEFAULT_INCOME
#     lauren_income = LAURENS_DEFAULT_INCOME
# else:
nicole_income = NICOLES_DEFAULT_INCOME
lauren_income = LAURENS_DEFAULT_INCOME
cols = st.columns(2)
with cols[0]:
    expenses1 = st.slider("Nicole's Annual Cost of Living", 0, MAX_INCOME, step=100, value=int(100*round(expenses_by_income(nicole_income)/100)), format='$%.2f', key='expenses1')
    st.metric(f'Percentage of Income', f'{100*expenses1/nicole_income:,.2f}%')

with cols[1]:
    expenses2 = st.slider("Lauren's Annual Cost of Living", 0, MAX_INCOME, step=100, value=int(100*round(expenses_by_income(lauren_income)/100)) , format='$%.2f')
    st.metric(f'Percentage of Income', f'{100*expenses2/lauren_income:,.2f}%')
st.button("Reset to original values", key='m2')

# st.markdown(f'**X had to find a new cashier job after a {str(int(unemployment[1] - unemployment[0]))}-long stretch of unemployment, while Y went without employment for {str(int(tf - t0))} years time.**')
# st.write(unemployment)
st.text(f'Assuming ${nicole_income:,.2f} income for Nicole, ${lauren_income:,.2f} income for Lauren.')

# y1 = income*(t-t0) - (t>unemployment[0])*income*(t-unemployment[0]) + (t>unemployment[1])*income*(t-unemployment[1]) - (t-t0)*expenses1
# y2 = (income+income_difference)*(t-t0) - expenses2*(t-t0) 

y1 = (nicole_income - expenses1)*(t-t0)
y2 = (lauren_income - expenses2)*(t-t0)



plot = go.Figure([go.Scatter(x=t, y=y1, name = "Nicole"), go.Scatter(x=t, y=y2, name = "Lauren")])
plot.update_yaxes(rangemode="tozero")

st.plotly_chart(plot)
cols = st.columns(3)
with cols[0]:
    st.metric(f'Starting Net Worth Difference ({str(int(t0))})', f'${y2[0] - y1[0]:,.2f}')
with cols[1]:
    st.metric(f'Ending Net Worth Difference ({str(int(tf))})', f'${y2[-1] - y1[-1]:,.2f}')
with cols[2]:
    st.metric(f'Ending Net Worth Multiple ({str(int(tf))})', f'{y2[-1]/y1[-1]:.2f}x')








st.markdown('<br> <br> <br>', unsafe_allow_html=True)

# SECTION: Employment Security
st.subheader('Employment Security')

# st.markdown('D.C. had one of the highest Black unemployment rates in the country, and “last hired first fired” ')
st.markdown("""
Gaps in employment contribute to differences in wealth growth between racial groups. Data from 2021 shows that Black U.S. residents are more likely to be unemployed than White residents (with a national Black-White unemployment rate ratio of 1.6), and this difference is even larger in Washington D.C., where Black individuals were four times more likely to be unemployed than White DC residents (with a D.C. Black-White unemployment rate ratio of 4.0).<sup>9</sup> D.C. has a higher Black-White unemployment ratio compared to neighboring states due to racial segregation and the unique emphasis on white-collar federal employment in D.C.<sup>10</sup> White D.C. residents are more likely than Black D.C. residents to have access to high salary professional or social job networks, which can perpetuate racial inequalities in hiring practices because those with a more robust job network are more likely to be aware of job openings and are more likely to receive a social referral.<sup>10</sup>
""", unsafe_allow_html=True)

st.markdown("""
The duration of periods of unemployment also differs by race. In D.C. from 2021-2022, White residents had an average of 23.1 weeks unemployed (~44% of a year) while Black residents had an average of 26.8 weeks unemployed (~51% of a year).<sup>12</sup> Gaps in employment lead to longer periods without income, and in periods of economic shock (such as a recession) Black families nationally take longer to recover because Black workers are often “last hired” during economic recoveries.<sup>13,14</sup>
""", unsafe_allow_html=True)

st.markdown("""
**In this scenario, imagine that Nicole experiences 26 weeks of unemployment in a year, while Lauren experiences 23 weeks of unemployment in a year. During her period of unemployment, Lauren had access to extensive professional and social networks with connections in the legal profession. Her professional networks notified and referred her for high salary job openings, reducing her period of unemployment and income loss.**
""")

st.markdown("""
**Use the sliders below to see how differing stretches of unemployment for Nicole and Lauren widen the net worth gap. If you check the “Equalize Lauren and Nicole’s Income and Expenses” box, you can see the impacts of unemployment even if income and expenses are equal for the two women.**
""")


t_emp = np.arange(t0, tf, step=1/WEEKS_PER_YEAR) # NOTE for employment security plot, swtich to weekly timeseries

income_checkbox = st.checkbox("Equalize Lauren and Nicole's Income and Expenses.", value=True)

if income_checkbox:
    nicole_income = LAURENS_DEFAULT_INCOME
    lauren_income = LAURENS_DEFAULT_INCOME
else:
    nicole_income = NICOLES_DEFAULT_INCOME
    lauren_income = LAURENS_DEFAULT_INCOME

    

cols = st.columns(2)
with cols[0]:
    unemployment1 = st.slider("Nicole: Weeks Unemployed per Year", 0, WEEKS_PER_YEAR, step=1, value=26)

with cols[1]:
    unemployment2 = st.slider("Lauren: Weeks Unemployed per Year", 0, WEEKS_PER_YEAR, step=1, value=23)

st.button("Reset to original values", key='m3')



nicole_income_annual = nicole_income*(1 - unemployment1/WEEKS_PER_YEAR)
lauren_income_annual = lauren_income*(1 - unemployment2/WEEKS_PER_YEAR)
st.text(f'Assuming ${nicole_income:,.2f} annual salary for Nicole, and \n${lauren_income:,.2f} annual salary for Lauren.')

y1 = nicole_income*(t_emp-t0) - expenses_by_income(nicole_income_annual)*(t_emp-t0) - (nicole_income/WEEKS_PER_YEAR)*(np.mod(t_emp-t0, 1) >=1 - (unemployment1/WEEKS_PER_YEAR)).cumsum()
y2 = lauren_income*(t_emp-t0) - expenses_by_income(lauren_income_annual)*(t_emp-t0) -(lauren_income/WEEKS_PER_YEAR)*(np.mod(t_emp-t0, 1) >=1 - (unemployment2/WEEKS_PER_YEAR)).cumsum()

plot = go.Figure([go.Scatter(x=t_emp, y=y1, name = "Nicole"), go.Scatter(x=t_emp, y=y2, name = "Lauren")])
# plot.update_yaxes(rangemode="tozero")

st.plotly_chart(plot)
cols = st.columns(3)
with cols[0]:
    st.metric(f'Starting Net Worth Difference ({str(int(t0))})', f'${y2[0] - y1[0]:,.2f}')
with cols[1]:
    st.metric(f'Ending Net Worth Difference ({str(int(tf))})', f'${y2[-1] - y1[-1]:,.2f}')
with cols[2]:
    st.metric(f'Ending Net Worth Multiple ({str(int(tf))})', f'{y2[-1]/y1[-1]:.2f}x')

if y2[-1]/y1[-1] <= 0:
    st.warning("Net Worth Multiple less than zero indicates that either Lauren or Nicole is in debt.  In this case, a low negative multiple means that one person's wealth is comparable to another's indebtedness.")






st.markdown('<br> <br> <br>', unsafe_allow_html=True)

# SECTION: Feedback Loops
st.header('Feedback Loops: wealth generates wealth, debt generates debt')
# st.markdown('<br> <br> <br>', unsafe_allow_html=True)



# st.markdown('<br> <br> <br>', unsafe_allow_html=True)
st.markdown('<br> ', unsafe_allow_html=True)


# SECTION: Inherited Wealth
st.subheader('Inherited Wealth')

st.markdown("""
Inheritances contribute roughly 4 percent of annual household income (and are usually untaxed by the U.S. government), preserving a history of monetary inequality as wealth is passed down from generation to generation.<sup>15</sup> According to data from the Federal Reserve Board, 26% of White families receive an inheritance, while only 8% of Black families do. Additionally, the average inheritance value for Black families in the United States is 35% that of White families, further increasing the disparities in inherited wealth.<sup>16</sup> he inherited wealth differential can have downstream effects, leaving Black families on average with fewer resources available for wealth building. These effects are passed along from generation to generation.
""", unsafe_allow_html=True)

st.markdown("""
**If Lauren’s inheritance is \$100,000, according to the national average Nicole’s inheritance would be \$35,000. For now, assume an equal rate of return on the inheritances. Use the sliders to see how changing the inheritance amounts for the two women impacts the wealth gap.  The next section will discuss how different rates of return can further widen this gap.**
""")
# income_checkbox = st.checkbox("Equalize Lauren and Nicole's Income, Expenses.", value=True)
# if income_checkbox:
#     nicole_income = LAURENS_DEFAULT_INCOME
#     lauren_income = LAURENS_DEFAULT_INCOME
# else:
#     nicole_income = NICOLES_DEFAULT_INCOME
#     lauren_income = LAURENS_DEFAULT_INCOME
cols = st.columns(2)
with cols[0]:
    inheritance1 = st.slider("Nicole's Inheritance", 0, MAX_INHERITANCE, INHERITANCE_DEFAULT_NICOLE, 1000, format='$%.2f')
with cols[1]:
    inheritance2 = st.slider("Lauren's Inheritance", 0, MAX_INHERITANCE, INHERITANCE_DEFAULT_LAUREN, 1000, format='$%.2f')
st.button("Reset to original values", key='m4')

r=ROR_STOCKS
st.text(f'Assuming {r:.1f}% return on assets, with no income.')


# Compound interest only
y1 = inheritance1*(np.power(1+r/100, (t-t0))) 
y2 = inheritance2*(np.power(1+r/100, (t-t0)))

plot = go.Figure([go.Scatter(x=t, y=y1, name = "Nicole"), go.Scatter(x=t, y=y2, name = "Lauren")])
plot.update_yaxes(rangemode="tozero")

st.plotly_chart(plot)
cols = st.columns(3)
with cols[0]:
    st.metric(f'Starting Net Worth Difference ({str(int(t0))})', f'${y2[0] - y1[0]:,.2f}')
with cols[1]:
    st.metric(f'Ending Net Worth Difference ({str(int(tf))})', f'${y2[-1] - y1[-1]:,.2f}')
with cols[2]:
    st.metric(f'Ending Net Worth Multiple ({str(int(tf))})', f'{y2[-1]/y1[-1]:.2f}x')



st.markdown('<br> <br>', unsafe_allow_html=True)

# SECTION: Return from investments
st.subheader('Return from investments: how wealth generates wealth')

st.markdown("""
Those with higher incomes and more accumulated wealth will have more money left after covering living expenses and can invest more, in turn earning larger returns on the larger principal. Larger return on investment increases the amount an individual or household can then further invest, continuing the wealth generating cycle. Some financial tools and services which offer higher returns on investments, such as high-interest savings or brokerage and advisory accounts, may require a minimum deposit, and/or market only to customers in a higher income bracket. Further, high-return investments carry greater risk of financial loss, especially in the short term, and the financial stability of people with lower income is more sensitive to that risk. 
""")

st.markdown("""
Homeownership can also be a key form of investment; for many families, their home is one of their largest assets and differential property value appreciation leads to exponential differences in wealth. Racial income disparity like that in Washington, D.C. results in higher rates of return on investment for White households compared to Black households.<sup>17</sup> Housing value appreciates differently in White and Black neighborhoods.<sup>18</sup> Additionally, Black families can face challenges to investing in home ownership due to housing discrimination and the ongoing impacts of segregation and redlining. Furthermore, being underbanked or unbanked (having less or no access to banks) limits the ability of Black families to accumulate interest over time and their ability to accelerate wealth building through higher return financial investments.<sup>19</sup> The median amount in checking and savings was \$425 for Black households vs. \$7,000 for White households in 2019.<sup>20</sup> On the other hand, White families are more likely to invest in the stock market and have riskier investments with higher rewards<sup>21</sup>; in 2019 the median amount in brokerage accounts was \$28,000 for White households versus \$9,000 for Black households.<sup>22</sup> In addition, some workers (typically in higher wage jobs) also have access to tax-advantaged financial assets through their employer. As discussed earlier, occupational segregation may mean that Black residents are less likely to have access to these assets than their White counterparts.  For instance, in 2019 the median amount in retirement accounts was \$50,000 for Black households versus \$110,000 for White households.<sup>23</sup> Building wealth through higher incomes, owning a home, growing savings and lower debt values provides cushion to absorb financial stocks (such as unexpected car or health expenditures), financial stressors or missteps. 
""", unsafe_allow_html=True)

st.markdown("""
**Use the sliders below to see how a difference in the rate of return on assets affects Lauren and Nicole's net worth. In this model, the sliders only correspond to the interest Lauren and Nicole are earning on their inheritance in the previous graph. Other sources of wealth such as income are not included here, but these factors would further increase the difference in return on investment.**
""")


inheritance1 = INHERITANCE_DEFAULT_NICOLE
inheritance2 = INHERITANCE_DEFAULT_LAUREN

cols = st.columns(2)
with cols[0]:
    asset_return_rate1 = st.slider("Nicole's Annual Asset Return Rate", 0.0, MAX_ROR, INTEREST_SAVINGS, .01, format='%%%.2f')
    # starting_assets1 = st.slider("Nicole's Starting Assets", 0, 100000, 59000, 1000, format='$%.2f')
with cols[1]:
    asset_return_rate2 = st.slider("Lauren's Annual Asset Return Rate", 0.0, MAX_ROR, ROR_STOCKS, .01, format='%%%.2f')
    # starting_assets2 = st.slider("Lauren's Starting Assets", 0, 200000, 150000, 1000, format='$%.2f')
st.button("Reset to original values", key='m5')


st.text('Assuming no income.') 

y1 = (inheritance1)*(np.power(1+(asset_return_rate1)/100, (t-t0)))
y2 = (inheritance2)*(np.power(1+asset_return_rate2/100, (t-t0)))

plot = go.Figure([go.Scatter(x=t, y=y1, name = "Nicole"), go.Scatter(x=t, y=y2, name = "Lauren")])
plot.update_yaxes(rangemode="tozero")

st.plotly_chart(plot)
cols = st.columns(3)
with cols[0]:
    st.metric(f'Starting Net Worth Difference ({str(int(t0))})', f'${y2[0] - y1[0]:,.2f}')
    
with cols[1]:
    st.metric(f'Ending Net Worth Difference ({str(int(tf))})', f'${y2[-1] - y1[-1]:,.2f}')
with cols[2]:
    st.metric(f'Ending Net Worth Multiple ({str(int(tf))})', f'{y2[-1]/y1[-1]:.2f}x')













st.markdown('<br> <br>', unsafe_allow_html=True)


# SECTION: Interest on debt
st.subheader('Interest on debt: how debt generates debt')

st.markdown("""
Debt can also lead to continued cycles of debt. Debt earns interest, adding to the original amount owed. If a debt is not paid off, it will increase as interest and the amount owed continue to accumulate over time. Sources of debt can include medical expenses, student loans, auto loans, and credit card charges, and some types of debt accrue interest more quickly than others. When debt has a high interest rate and/or an individual’s income or life circumstances limit their ability to keep up with payments, credit scores can decline, leading to further increases in interest rates on loans.  
""")

st.markdown("""
In D.C., communities of color are five times more likely to have debt in collections than White communities<sup>24</sup>, while White D.C. residents have lower median debt values, in addition to higher median income and home value.<sup>25</sup> Banking access and policies can also impact debt. Black residents can often experience lower banking access, higher banking fees, and a higher percentage of income required to deposit to avoid fees.<sup>26</sup> Combined with distrust due to prior discriminatory and predatory practices, many Black residents may turn to short-term loan options rather than a bank. These short-term options, such as informal savings clubs have higher fees and fewer consumer protections.   
""", unsafe_allow_html=True)

st.markdown("""
Student loans are a frequent form of debt, and Black D.C. households are more likely than White households to have student loan debt.<sup>27</sup> Since 2006, undergraduate direct and federal subsidized student loan interest rates have ranged from 2.75\% to 6.8\%.<sup>28</sup> When a student does not complete a college degree, it is more difficult to pay back the loans, which can lead to increased debt in early adulthood that can carry forward in life. Additionally, predatory student lending (including misleading students about promises for low tuition and job prospects/income expectations after graduation) has a disproportionate impact on minorities.<sup>29</sup> Parental support is the greatest financial contribution to most students’ educations at an annual average of \$11,86230; however, parents with less accumulated wealth (due to the factors and feedback loops discussed on this page) sometimes cannot afford to contribute to higher education costs.
""", unsafe_allow_html=True)



st.markdown("""
**Assuming Nicole has a student loan debt of \$23,400 and Lauren has a student loan debt of \$16,000 (the 2016 average debts for Black versus White college graduates<sup>31</sup>), you can position the sliders for their respective incomes to see how their debt burden changes over time. As an individual’s income increases, they are able to pay off the debt faster, reducing the amount of interest accrued. You can also adjust the sliders for amount borrowed for each individual to see the impacts.**
""", unsafe_allow_html=True)


income_checkbox = st.checkbox("Equalize Lauren and Nicole's Income + Expenses.", value=True)
if income_checkbox:
    nicole_income = LAURENS_DEFAULT_INCOME
    lauren_income = LAURENS_DEFAULT_INCOME
else:
    nicole_income = NICOLES_DEFAULT_INCOME
    lauren_income = LAURENS_DEFAULT_INCOME
st.text(f'Assuming ${nicole_income:,.2f} income for Nicole, ${lauren_income:,.2f} income for Lauren, \n2021 Federal Student Loan Rate of 3.73%, and annual asset return rates from above.')


cols = st.columns(2)
with cols[0]:
    loan_size1 = st.slider("Amount Nicole Borrowed", 0, MAX_AMT_BORROWED, NICOLE_AMT_BORROWED_DEFAULT, 100, format='$%.2f')
    income1 = st.slider("Nicole's Income", 0, MAX_INCOME, nicole_income, 1000, format='$%.2f')
    # apr1 = st.slider("Nicole's Annual Percentage Rate", 0, 100, 7, 1, format='%%%.2f')
with cols[1]:
    loan_size2 = st.slider("Amount Lauren Borrowed", 0, MAX_AMT_BORROWED, LAUREN_AMT_BORROWED_DEFAULT, 100, format='$%.2f', key='income12')
    income2 = st.slider("Lauren's Income", 0, MAX_INCOME, lauren_income, 1000, format='$%.2f', key='income22')
    # apr2 = st.slider("Lauren's Annual Percentage Rate", 0, 100, 7, 1, format='%%%.2f')
st.button("Reset to original values", key='m6')



debt = [loan_size1, loan_size2]
invested = [0,0]
y1 = [0] * len(t)
y2 = [0] * len(t)


for ind in range(1,len(t)):
    debt[0], invested[0] = balance_step(debt[0], invested[0], income1, expenses_by_income(income1), FEDERAL_STUDENT_LOANS_RATE_2022/100, ROR_STOCKS/100)
    debt[1], invested[1] = balance_step(debt[1], invested[1], income2, expenses_by_income(income2), FEDERAL_STUDENT_LOANS_RATE_2022/100, ROR_STOCKS/100)
    y1[ind]= invested[0] - debt[0]
    y2[ind]= invested[1] - debt[1]


plot = go.Figure([go.Scatter(x=t, y=y1, name = "Nicole"), go.Scatter(x=t, y=y2, name = "Lauren"), go.Scatter(x=t, y=[0]*t.shape[0], name = '$0', line=dict(color='black', width=0.5))])
plot.update_yaxes(rangemode="tozero")

st.plotly_chart(plot)
cols = st.columns(3)
with cols[0]:
    st.metric(f'Starting Net Worth Difference ({str(int(t0))})', f'${y2[0] - y1[0]:,.2f}')
with cols[1]:
    st.metric(f'Ending Net Worth Difference ({str(int(tf))})', f'${y2[-1] - y1[-1]:,.2f}')
with cols[2]:
    st.metric(f'Ending Net Worth Multiple ({str(int(tf))})', f'{y2[-1]/y1[-1]:.2f}x')

if y2[-1]/y1[-1] <= 0:
    st.warning("Net Worth Multiple less than zero indicates that either Lauren or Nicole is in debt.  In this case, a low negative multiple means that one person's wealth is comparable to another's indebtedness.")





st.markdown('<br> <br> <br>', unsafe_allow_html=True)


# SECTION: Putting it all together
st.header('Putting it all together')

st.markdown("""
In this household finance dynamic model we see that white Washington D.C. residents start in a stronger financial position than Black residents, putting them in a better position to be able to continue building wealth over time. Because multiple factors (such as income, job security, cost of living, inherited wealth, ability to invest money, debt, and more) influence the wealth gap, effective interventions to decrease the racial wealth gap must be highly coordinated. Isolated interventions, such as increasing salaries or employment or lowering costs will not close the gap because disparities in each contributing factor compound. 
""")

# Bring back all the values
nicole_income = NICOLES_DEFAULT_INCOME
lauren_income = LAURENS_DEFAULT_INCOME

cols = st.columns(2)
with cols[0]:
    income1 = st.slider("Nicole's Income", 0, MAX_INCOME, nicole_income, 1000, format='$%.2f', key='income1b')
    # unemployment1 = st.slider("Nicole: Weeks Unemployed per Year", 0, WEEKS_PER_YEAR, step=1, value=27, key = 'unemployment1b')
    expenses1 = st.slider("Nicole's Annual Cost of Living", 0, MAX_INCOME, step=1000, value=int(expenses_by_income(nicole_income)), format='$%.2f', key='expenses1b')
    inheritance1 = st.slider("Nicole's Inheritance", 0, MAX_INHERITANCE, INHERITANCE_DEFAULT_NICOLE, 1000, format='$%.2f', key='inheritance1b')
    loan_size1 = st.slider("Amount Nicole Borrowed", 0, MAX_AMT_BORROWED, NICOLE_AMT_BORROWED_DEFAULT, 1000, format='$%.2f', key='loan1b')
    asset_return_rate1 = st.slider("Nicole's Annual Asset Return Rate", 0.0, MAX_ROR, INTEREST_SAVINGS, .01, format='%%%.2f',key='ror1b')
with cols[1]:
    income2 = st.slider("Lauren's Income", 0, MAX_INCOME, lauren_income, 1000, format='$%.2f', key='income2b')
    # unemployment2 = st.slider("Lauren: Weeks Unemployed per Year", 0, WEEKS_PER_YEAR, step=1, value=23, key='unemployment2b')
    expenses2 = st.slider("Lauren's Annual Cost of Living", 0, MAX_INCOME, step=1000, value=int(expenses_by_income(lauren_income)) , format='$%.2f', key='expenses2b')
    inheritance2 = st.slider("Lauren's Inheritance", 0, MAX_INHERITANCE, INHERITANCE_DEFAULT_LAUREN, 1000, format='$%.2f',key='inheritance2b')
    loan_size2 = st.slider("Amount Lauren Borrowed", 0, MAX_AMT_BORROWED, LAUREN_AMT_BORROWED_DEFAULT, 1000, format='$%.2f', key='loan2b')
    asset_return_rate2 = st.slider("Lauren's Annual Asset Return Rate", 0.0, MAX_ROR, ROR_STOCKS, .01, format='%%%.2f',key= 'ror2b')


debt = [loan_size1, loan_size2]
invested = [inheritance1,inheritance2]
y1 = [0] * len(t)
y2 = [0] * len(t)

# adjustedIncome1 = income1 * (1 - unemployment1/WEEKS_PER_YEAR)
# adjustedIncome2 = income2 * (1 - unemployment2/WEEKS_PER_YEAR)


for ind in range(len(t)):
    y1[ind]= invested[0] - debt[0]
    y2[ind]= invested[1] - debt[1]
    debt[0], invested[0] = balance_step(debt[0], invested[0], income1, expenses1, FEDERAL_STUDENT_LOANS_RATE_2022/100, ROR_STOCKS/100)
    debt[1], invested[1] = balance_step(debt[1], invested[1], income2, expenses2, FEDERAL_STUDENT_LOANS_RATE_2022/100, ROR_STOCKS/100)



plot = go.Figure([go.Scatter(x=t, y=y1, name = "Nicole"), go.Scatter(x=t, y=y2, name = "Lauren"), go.Scatter(x=t, y=[0]*t.shape[0], name = '$0', line=dict(color='black', width=0.5))])
plot.update_yaxes(rangemode="tozero")

st.plotly_chart(plot)
cols = st.columns(3)
with cols[0]:
    st.metric(f'Starting Net Worth Difference ({str(int(t0))})', f'${y2[0] - y1[0]:,.2f}')
with cols[1]:
    st.metric(f'Ending Net Worth Difference ({str(int(tf))})', f'${y2[-1] - y1[-1]:,.2f}')
with cols[2]:
    st.metric(f'Ending Net Worth Multiple ({str(int(tf))})', f'{y2[-1]/y1[-1]:.2f}x')



st.markdown("""
This final model shows the cumulative effects of each of the factors discussed on this page over a 20-year period on Nicole and Lauren’s net worth. Interest generates additive effects for both wealth building and debt so just as some individuals or families build wealth over time, others can sink further into a cycle of debt. 
""")

st.markdown("""
Models like these can be extended and enhanced with community input, survey data, and social science research. Thus, policymakers can evaluate the financial impact of proposed policies and interventions in their communities.
""")

st.markdown("""
## References

<sup>1</sup> <https://www.urban.org/research/publication/color-wealth-nations-capital>

<sup>2</sup> Data USA, “Data USA: Washington, DC,” [Online]. Available: <https://datausa.io/profile/geo/washington-dc/>. [Accessed 4 June 2021].

<sup>3</sup> <https://www.dcfpi.org/wp-content/uploads/2020/01/Black-Workers-Matter-PDF-2.pdf>

<sup>4</sup> <https://www.dcfpi.org/wp-content/uploads/2020/01/Black-Workers-Matter-PDF-2.pdf>

<sup>5</sup> The Racial Wealth Gap in Washington D.C. <https://sjp.mitre.org/resources/MITRE-DC-Racial-Wealth-Gap-Study.pdf>

...

""", unsafe_allow_html=True)