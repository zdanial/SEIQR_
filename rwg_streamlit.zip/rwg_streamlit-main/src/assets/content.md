# Household Finance Dynamics

## Topics
- Intro to Compound Interest
- Linear Growth from Income vs Borrow for Spending Gap
- Household Finance MiniModel
- Household Profiles
- Understanding the Gap
- Simulation
- Bring back to Data (Features)
- Conclusion

## Introduction to Compound Interest
Whether you are making an investment or someone is investing in you (loan), we expect some return for risking our capital

- Returns from stock investments are either determined by the market (asset appreciation) or management (dividends)
- Returns from fixed income (bonds, loans) are determined by a prespecified interest rate

If one reinvests their gains from interest they begin to earn ‘interest on interest’, resulting in exponential growth of asset value from the compound interest

## Linear Growth from Income vs Borrow for Spending Gap
When ones income exceeds their expenses, the savings grow linearly (unless invested).  On the other hand, if one’s expenses exceed their income, the debt they accrue grows exponentially

## Household Finance MiniModel
- We propose a simple model to capture these dynamics without too many degrees of freedom
    - Asset bundles produces annual return rA, returns can be reinvested or taken to cash
    - Loan takes the place of a mortgage (low interest rate rL)
    - Debt takes the place of a Credit Card (high interest rate rD)
    - rD >> rA > rL
- Model Flow
    - Income is matched with expenses to see if there is excess income– if not, Household must borrow to cover spending gap
    - Cash is allocated to paying back debt and loan, as well as investing
- Deterministic model projects forward based on initial conditions and control variables


## Mapping to PSID Data
- Assets = Home Value + Farm/Business Value + CDS/Bonds Value + Real Estate Value + Stocks Value + IRA/Annuity Value + Other Assets
- Cash = Checking/Savings Value + <span style="color:red">?Vehicle Value?</span>
- Loan = (Home Value – Home Equity Value) + Farm/Business Debt + Other Real Estate Debt
- Debt = Credit Card Debt + Student Loan Debt + Legal Debt + Family Loan Debt + Other Debt


## Stochasticity
Returns – random sample
Life events
Medical bills
Measure resilience to a large one-time expense
Unemployment
Expenses stay the same, income = 0, how long till net worth hits 0?

## Expenses
Looking at expenses by income, the median household needs at least ~$15,000/year regardless of income, and spends ~30% of every dollar above that.

## Two Household Comparison
Play around with the slider to see how difference in income changes a households ability to accumulate wealth.
