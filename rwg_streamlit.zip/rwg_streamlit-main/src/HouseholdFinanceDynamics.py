import numpy as np
import pandas as pd


# income, expenses = 10,000 + 4/10*(income)
# asset, loan, high interest debt
# income - expenses - pmt => borrow or split into invest
# split asset appreciation into save profit or reinvest invest


class H:
    E = (
        lambda I: 10000 + 0.4 * I
    )  # Expenses are soft-coded $10,0000 neccessary + 40% of Income
    interest = lambda r, P: r * P

    # TODO name variables
    def __init__(
        self,
        inits,
        dt=1,
        start=0,
        stop=10,
        stoch_asset=False,
        life_event=False,
        unemployment=False,
    ):
        self.time = np.arange(start, stop + dt, dt)
        self.dt = dt
        self.X0 = inits
        self.X0["t"] = self.time[0]
        self.X0["i"] = 0
        self.traj = [self.X0]

        if stoch_asset != False:
            stoch_asset["size"] = self.time.shape[0]
            self.rg = np.random.lognormal(
                **stoch_asset
            ) -1  # TODO add source for log normal
            # print(self.rg)
            self.stoch_asset = stoch_asset
        else:
            self.rg = np.zeros(self.time.shape[0])
            self.stoch_asset = stoch_asset

        self.unemployment = unemployment
        self.life_event = life_event

    def ddt(self, I0, C, A, L, D, rg, rL, rD, ag, t, i, V=0, **kwargs):
        dC, dA, dD, dL = 0, 0, 0, 0
        S = I0 - kwargs['E']#H.E(I0)  # Income after expenses = I - E

        if self.unemployment != False:
            S -= (t >= self.unemployment) * I0  # subtract income if unemployed
        if self.life_event != False:
            S -= (
                (t == self.life_event[1]) * self.life_event[0] / self.dt
            )  # subtract life event

        # calculate interest expense
        L_interest = H.interest(rL, L)
        D_interest = H.interest(rD, D)
        total_interest = L_interest + D_interest

        # Cash Acct + Income after expenses + Asset returns
        c = (
            C
            + S
            # + rg * A * (1 - ag) * (self.stoch_asset == False)
            # + (-1 if np.random.uniform() > 0.5 else 1)
            # * self.rg[i]
            # * A
            # * (1 - ag)
            # * (self.stoch_asset != False)
        )

        if c < 0 and A > 0:
            # if out of cash, and still have assets, liquidate to cover expenses
            tmp = np.min([-c, A])
            c += tmp
            dA -= tmp / self.dt

        if c >= total_interest:
            # If cash covers total interest, try to pay back principle
            c -= total_interest
            d = np.min([c, D])
            c -= d
            dD += -d

            l = np.min([c, L / 10]) # pay down max 10% of outstanding loan per year
            c -= l
            dL += -l
        elif c <= 0:
            # if expnses >= income, borrow to cover expenses + interest
            dD += -c + D_interest
            dL += L_interest
            c = 0

        elif c < total_interest:
            # else pay interest proportionally , TODO highlight this in assumptions
            dD += D_interest - (D_interest / (L_interest + D_interest)) * c
            dL += L_interest - (L_interest / (L_interest + D_interest)) * c
            c = 0

        dA += ag * (c - C) + (rg * A * (self.stoch_asset == False)
            + (-1 if np.random.uniform() > 0.5 else 1)
            * self.rg[i]
            * A
            * (self.stoch_asset != False) ) 
        dC += (1 - ag) * (c - C) # + rg*A*(1-ag)

        return (dC, dA, dD, dL)

    def run(self):
        for i, t in enumerate(self.time[1:]):
            X = self.traj[-1]
            dd = self.ddt(**X)
            X1 = X.copy()
            X1["C"] += dd[0] * self.dt
            X1["A"] += dd[1] * self.dt
            X1["D"] += dd[2] * self.dt
            X1["L"] += dd[3] * self.dt
            X1["t"] = t
            X1["i"] = i + 1
            # X1['rg'] = np.random.normal(0, 0.1)
            self.traj.append(X1)

        df = pd.DataFrame(self.traj)
        # df['t'] = self.time
        self.output = df


if __name__ == "__main__":
    import matplotlib.pyplot as plt

    dt = 1
    time = np.arange(0, 10, dt)

    X0 = dict(
        I0=10000.0,
        C=20000.0,
        A=10000.0,
        L=0.0,
        D=0.0,
        rg=0.05,
        rL=0.2,
        rD=0.18,
        ag=0.8,
    )
