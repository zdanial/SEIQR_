import streamlit as st
import copy
import pandas as pd
import plotly.graph_objects as go
import plotly.express.colors as colors
import numpy as np
import matplotlib.pyplot as plt
import json
import os
try:
    del H
except:
    pass
from HouseholdFinanceDynamics import H

from st_on_hover_tabs import on_hover_tabs

import streamlit_analytics

streamlit_analytics.start_tracking()

st.set_page_config(layout='wide', page_title='Household Finance Model', page_icon = '📈')
web_text = json.load(open('./src/assets/webpage_text.json', 'r'))

st.markdown('<link rel="stylesheet"href="https://fonts.googleapis.com/css?family=Arimo">', unsafe_allow_html=True)
st.markdown('<img src="https://comm.mitre.org/strategiccommunications/wp-content/uploads/sites/170/2020/01/MITRE_logos_Base.jpg" width=150>', unsafe_allow_html=True)
st.title(web_text['title'])
st.markdown(web_text['intro']+'<hr>', unsafe_allow_html=True)

st.markdown('<style>' + open('src/assets/style.css').read() + '</style>', unsafe_allow_html=True)
st.markdown('<style>footer {visibility: hidden;height: 0%;}</style>', unsafe_allow_html=True)

# st.write(os.getcwd())



with st.sidebar:
    tabs = on_hover_tabs(tabName=['Dashboard', 'Comparison', 'Model Description'], 
                        iconName=['dashboard', 'compare', 'description'], default_choice=0, 
                        styles = {'navtab': {'background-color':'#F1F3F4',
                                                  'color': '#0D2F4F',
                                                  'font-size': '18px',
                                                  'transition': '.3s',
                                                  'white-space': 'nowrap',
                                                  'text-transform': 'capitalize'},
                                    'tabOptionsStyle': {':hover :hover': {'color': '#005B94',
                                                        'cursor': 'pointer'}},})





@st.cache
def get_data():
    df = pd.read_csv('./src/data/psid_panel_data.csv')
    df.fillna(0, inplace=True)
    df = df.groupby(['year', 'ref_race', 'own_rent', 'educ']).median()
    Asset_columns = ['home_val', 'farm_business_val', 'cds_bonds_val', 'real_estate_val', 'stocks_val', 'annuity_ira_val','other_assets_val']
    Cash_columns = ['checking_savings_val']#,  'vehicle_val',] # 'amt_credit_saving_etc',
    Loan_columns = ['home_val', 'home_equity_val','farm_business_debt', 'other_real_estate_debt',]
    Debt_columns = ['credit_card_debt', 'student_loan_debt','legal_debt', 'family_loan_debt','other_debt']

    df['A'] = df['home_val'].fillna(0)
    for i, asset in enumerate(Asset_columns[1:]):
        df['A'] = df.A + df[asset].fillna(0)

    df['C'] = df['checking_savings_val'].fillna(0)
    for i, cash in enumerate(Cash_columns[1:]):
        df['C'] = df.C + df[cash].fillna(0)

    df['L'] = (df['home_val'].fillna(0) - df['home_equity_val'].fillna(0))
    for i, loan in enumerate(Loan_columns[2:]):
        df['L'] = df.L + df[loan].fillna(0)

    df['D'] = df['credit_card_debt'].fillna(0)
    for i, debt in enumerate(Debt_columns[1:]):
        df['D'] = df.D + df[debt].fillna(0)

    df['D'] = -df.D

    df['I'] = df.tot_fam_inc.fillna(0)
    df['E'] = df.tot_food_exp + df.tot_healthcare_exp + df.tot_transportation_exp + df.childcare_exp + df.tot_healthcare_exp \
        + df.edu_exp + df.home_insurance_exp + df.mont_rent.fillna(0) + df.tot_utility_exp + df.clothing_exp.fillna(0) \
            + df.recreation_entertainment_exp.fillna(0) + df.trips_exp.fillna(0)
    data = df[['A', 'C', 'L', 'D', 'I', 'E']].copy(deep=True)
    
    data['V'] = df.vehicle_val # replace df.vehicle_val with 0 to turn off inclusion of vehicle in net worth
    data['NW'] = data.A + data.C - data.L - data.D + data.V
    return data

data = get_data()


ss = st.session_state
if 'stoch_asset_tuple' not in ss:
    ss.stoch_asset_tuple = False
# if 'unemployment' not in ss:
#     ss.unemployment = 0
if 'life_event' not in ss:
    ss.life_event = False



if 'parameters' not in ss:
    ss['parameters'] = dict(
            I = 20000.0,
            C = 20000.0,
            A = 30000.0,
            L = 20000.0,
            D = 10000.0,
            rg= 0.05,
            rL = 0.03,
            rD = 0.18,
            V = 0,
            # aLs = 1.0,
            # aLi = 0.1,
            ag = .8,
        )

if 'year' not in ss:
    ss.year = 2019
        
if 'user_params' in ss:
    ss['parameters'] = ss['user_params']
else:
    ss['user_params'] = ss['parameters']


st.session_state['time'] = dict(start=0, stop=10, dt=1)

def reset_params():
    ss['user_params']['ag'] = 0.8
    ss['user_params']['rg'] = 0.05
    ss['user_params']['rL'] = 0.03
    ss['user_params']['rD'] = 0.18

def layout_params():
    cols = st.columns(6)
    with cols[-1]:
        st.button('Reset Assumptions', on_click=reset_params)

    st.subheader('Starting Account Balances')
    st.caption('The account balances for the four categories (Cash, Assets, high interest Debts, and low interest Loans) are intialized with the median values for the selected profile.  Use the sliders to see how things change over time due to changes in the initial conditions.')
    cols = st.columns(4)
    with cols[0]:
        C = st.slider(f'Cash ({year} Starting Balance $)', float(0), float(100000), step=float(10000), value=float(st.session_state['parameters']['C']))
    with cols[1]:
        # pass
        A = st.slider(f'Assets ({year} Starting Balance $)', float(0), float(1000000), step=float(10000), value=float(st.session_state['parameters']['A']))

    with cols[2]:
        # pass
        D = st.slider(f'High Interest Debt(s)  ({year} Starting Balance $)', float(0), float(100000), step=float(10000), value=float(st.session_state['parameters']['D']))
    with cols[3]:
        # pass
        L = st.slider(f'Low Interest Loan(s) ({year} Starting Balance $)', float(0), float(100000), step=float(10000), value=float(st.session_state['parameters']['L']))
    st.markdown("<br><br>", unsafe_allow_html=True)

    cols = st.columns([0.75, 0.25, 2])
    with cols[0]:
        st.subheader('Annual Parameters')
        st.caption("Modify the annual income and spending parameters.")
    with cols[-1]:  
        st.subheader('Assumptions')
        st.caption("Play with the interest rate and rate of return assumptions.  You can also use the check box to see how market volatility affects the balance sheet.")
    cols = st.columns([0.75, 0.25, 0.66, 0.66, 0.66])
    with cols[0]:
        I = st.slider('Annual Income ($)', 0.0, float(200000), step=float(10000), value=float(st.session_state['parameters']['I']))
        E = st.slider('Annual Expenses ($)', 0.0, 200000.0, step=float(10000), value= 10000.0 + 0.4 *float(st.session_state['parameters']['I']))
    with cols[2]:
        rg = st.slider('Rate of Return on Assets', float(0), float(10.0), value=100*float(st.session_state['parameters']['rg']), format='%.2f%%')
        st.caption('Check this box to add asset stochasticity into baseline case.')
        stoch_asset = st.checkbox('Stochastic Asset Returns', key='stoch_asset')
        if stoch_asset:
            ss.stoch_asset_tuple = dict(mean=rg/100, sigma=0.05)
        else:
            ss.stoch_asset_tuple = False
    with cols[3]:
        rD = st.slider('High Interest Debt(s) Interest Rate', float(0), float(50.0), value=100*float(st.session_state['parameters']['rD']), format='%.2f%%')
    with cols[4]:
        rL = st.slider('Low Interest Loan(s) Interest Rate', float(0), float(8.0), value=100*float(st.session_state['parameters']['rL']), format='%.2f%%')

    st.markdown("<br><br>", unsafe_allow_html=True)

    # cols = st.columns(2)
    cols = st.columns([0.75, 0.25, 1, 1])
    with cols[0]:
        st.subheader('Control Decision')
    with cols[2]:
        st.subheader('Scenario')

    cols = st.columns([0.75, 0.25, 1, 1])
    with cols[0]:
        ag = st.slider('Investment Rate', float(0), float(100.0), value=100*float(st.session_state['parameters']['ag'],), format='%.2f%%')
        st.caption('Use this slider to control the % of disposable income to invest.')
    with cols[2]:
        
        unemployment = st.slider('Unemployment (Starting in year)', (st.session_state['time']['start']), (st.session_state['time']['stop']), value=(0), step=(1), key='unemployment')
        st.caption('Simulate unemployment in the baseline case by dragging this slider to be a year greater than 0.  In the model a houshold still spends money on expenses but no longer has any income while unemployed.')
    with cols[3]:
        event_when = st.slider('Year of Life Event Occurence', (st.session_state['time']['start']), (st.session_state['time']['stop']), value=(2), step=(1), key='event_when')
        event_size = st.number_input('Life Event Size ($)', 0, 50000, value=0, step=10000, key='event_size')
        st.caption('Simulate a high impact life event using the slider and input to control the time and size of its occurence.')
        ss.life_event = (event_size, event_when) if event_when >st.session_state['time']['start'] else False

    ss.user_params= dict(
        I0 = I,
        E = E,
        C = C,
        A = A,
        L = L,
        D = D,
        rg= rg/100,
        rD = rD/100,
        rL = rL/100,
        V = 0,
        # aLs = aLs,
        # aLi = aLi,
        ag = ag/100,
    )



def run_sim(params, figure=True):
    try:
        unemp =  (ss.unemployment if ss.unemployment> st.session_state['time']['start'] else False)
    except:
        unemp = False

    x = H(params, dt=st.session_state['time']['dt'], start=st.session_state['time']['start'], stop=st.session_state['time']['stop'], 
                unemployment=unemp, life_event=ss.life_event, stoch_asset=ss.stoch_asset_tuple)
    x.run()

    df = x.output
    df['t'] = ss.year+df.t

    if figure:
        fig = go.Figure(data=[ 
            go.Scatter(x=df.t, y=(df.C+df.A+df.V), mode='lines', fill='tonexty', 
                fillcolor='#9bba9f', marker=dict(color='#9bba9f'), name='Assets', legendrank=3),
            go.Scatter(x=df.t, y=(df.C), fill='tozeroy', fillcolor='rgb(36, 141, 87)', marker=dict(color='rgb(36, 141, 87)'), mode='lines', name='Cash', legendrank=2),
                            # go.Scatter(x=df.t, y=np.zeros(df.shape[0]), fill='tonexty', marker=dict(color='white'), fillcolor='green', mode='lines'), 
                            ])
        fig.update_layout(template='simple_white', paper_bgcolor='rgba(255,255,255,1)',  yaxis_title="Dollars ($)")

        if (df.L>0).any():
            fig.add_trace(go.Scatter(x=df.t, y=-df.L, fill='tozeroy', marker=dict(color='#4f45bf'), fillcolor='#4f45bf', mode='lines', name='Loan', legendrank=4),)
            if (df.D>0).any():
                fig.add_trace(go.Scatter(x=df.t, y=-(df.D+df.L), fill='tonexty', marker=dict(color='#8d2424'), fillcolor='#8d2424', mode='lines', name='CC Debt', legendrank=5),)
        elif (df.D>0).any():
                fig.add_trace(go.Scatter(x=df.t, y=-(df.D), fill='tozeroy', marker=dict(color='#8d2424'), fillcolor='#8d2424', mode='lines', name='CC Debt', legendrank=5),)
        fig.add_trace(go.Scatter(x=df.t, y=(df.C+df.A+df.V)-(df.D+df.L),
                            mode='lines',
                            name='Net Worth', line=dict(color='#005B94', width=4), legendrank=1))
        # fig.update_layout(legend_traceorder="reversed")
        ss.fig = fig
        ss.df = df
    return df, x


def run_sensitivity(params):
    stochs = []
    for i in range(60):
        t = H(params, dt=st.session_state['time']['dt'], start=st.session_state['time']['start'], stop=st.session_state['time']['stop'], 
                    unemployment=(ss.unemployment if ss.unemployment> st.session_state['time']['start'] else False), life_event=ss.life_event, stoch_asset=(dict(mean=ss.user_params['rg'], sigma=0.2)))
        t.run()
        stochs.append(t.output)


    # ss.stoch_fig = go.Figure( data= [go.Scatter(x=df.t, y=(df.C+df.A+df.V)-(df.D+df.L), mode='lines',line=dict(color='yellow', width=4))] + [ go.Scatter(x=df.t, y=(v.C+v.A)-(v.D+v.L), opacity=0.5, mode='lines', line=dict(color='yellow', width=1, )) for v in stochs] )

    unemps = []
    for i in np.arange(st.session_state['time']['start'], st.session_state['time']['stop'], 2):
        t = H(params, dt=st.session_state['time']['dt'], start=st.session_state['time']['start'], stop=st.session_state['time']['stop'], 
                    unemployment=i, life_event=ss.life_event, stoch_asset=False)
        t.run()
        unemps.append(t.output)

    events = []
    for i in np.arange(0, 120000, 20000):
        t = H(params, dt=st.session_state['time']['dt'], start=st.session_state['time']['start'], stop=st.session_state['time']['stop'], 
                    unemployment=False, life_event=(i, ss.event_when), stoch_asset=False)
        t.run()
        events.append(t.output)

    df = ss.df
    
    colorscale = colors.sequential.Reds[::-1]

    

    ss.stoch_fig = go.Figure( data= [ go.Scatter(x=df.t, y=(v.C+v.A)-(v.D+v.L), name='', opacity=0.5, mode='lines', line=dict(color='#005B94', width=1, ), showlegend=False) for v in stochs] + [go.Scatter(x=df.t, y=(df.C+df.A+df.V)-(df.D+df.L), name='Net Worth', mode='lines',line=dict(color='#005B94', width=6))],)
    ss.stoch_fig.update_layout(template='simple_white',  yaxis_title="Dollars ($)")


    # colorbar_trace  = go.Scatter(x=[None],
    #                          y=[None],
    #                          mode='markers',
    #                          marker=dict(
    #                              colorscale=colorscale, 
    #                              showscale=True,
    #                              cmin=ss['time']['start'],
    #                              cmax=ss['time']['stop']-2,
    #                             #  colorbar=dict(thickness=5, tickvals=[-5, 5], ticktext=['Low', 'High'], outlinewidth=0)
    #                             colorbar=dict(
    # title="Unemployment at year",
    # tickvals=list(np.arange(ss['time']['start'], ss['time']['stop'], 2)),
    # # ticktext=[f"${i:,.2f}" for i in np.arange(0, 120000, 20000)],
    # )
    #                          ),
    #                          hoverinfo='none'
    #                         )



    ss.unemps_fig = go.Figure( data=  [ go.Scatter(x=df.t, y=(v.C+v.A)-(v.D+v.L), name='', opacity=0.8, mode='lines', line=dict(color=colorscale[i+1], width=3, ), showlegend=False) for i, v in enumerate(unemps)] 
        + [go.Scatter(x=df.t, y=(df.C+df.A+df.V)-(df.D+df.L), name='Net Worth', mode='lines',line=dict(color='#005B94', width=6))],  layout=dict(yaxis=dict(rangemode='nonnegative'))  )
    ss.unemps_fig['layout']['showlegend'] = False
    ss.unemps_fig.update_layout(template='simple_white',  yaxis_title="Dollars ($)")
    # ss.unemps_fig.add_trace(colorbar_trace)


    colorscale = colors.sequential.Reds
    
    colorbar_trace  = go.Scatter(x=[None],
                             y=[None],
                             mode='markers',
                             marker=dict(
                                 colorscale=colorscale, 
                                 showscale=True,
                                 cmin=0,
                                 cmax=100000,
                                #  colorbar=dict(thickness=5, tickvals=[-5, 5], ticktext=['Low', 'High'], outlinewidth=0)
                                colorbar=dict(
    title="Event Severity",
    tickvals=list(np.arange(0, 120000, 20000)),
    ticktext=[f"${i:,.2f}" for i in np.arange(0, 120000, 20000)],
    )
                             ),
                             hoverinfo='none'
                            )
    ss.events_fig = go.Figure( data= [ go.Scatter(x=df.t, y=(v.C+v.A)-(v.D+v.L), name='', opacity=0.8, mode='lines', line=dict(color=colorscale[i+1], width=3, ), showlegend=False) for i, v in enumerate(events)] + [go.Scatter(x=df.t, y=(df.C+df.A+df.V)-(df.D+df.L), name='Net Worth', mode='lines',line=dict(color='#005B94', width=6))],  )
    ss.events_fig['layout']['showlegend'] = False
    ss.events_fig.add_trace(colorbar_trace)
    ss.events_fig.update_layout(template='simple_white',  yaxis_title="Dollars ($)")
    # ss.events_fig.update_layout(coloraxis_colorbar=dict(
    # title="Event Severity ($)",
    # tickvals=np.arange(0, 120000, 20000),
    # ticktext=[f"${i:.2f}" for i in np.arange(0, 120000, 20000)],
    # ))


def plots():
    cols = st.columns(2)
    with cols[0]:
        st.subheader('Balance Sheet View')
        st.markdown("""
        The Balance Sheet Chart shows a breakout of the household's balance sheet as stacked areas. Each color corresponds to the balance in one of the four accounts in the model.  Liability balances are less than zero as the count against net worth.  The 'Net Worth' line is equal to the sum of the four accounts and is charted over time.  Does the households net worth **grow over time**?  Did they start out in debt?  Were they able to service their debt obligations and begin building wealth?  Do they stay at a **manageable level of debt** or enter a **debt spiral**?
        """)

    with cols[1]:
        st.subheader('Stochastic Asset Returns (Randomness)')
        st.markdown("""
        Market volatility can reward investors in some years, and take just the same.  This plot shows the effects of randomness on the net worth trajectory from investing in risk-bearing assets.  It allows us to understand the **distribution of outcomes** represented by the initial conditions and assumptions.  Does the household **risk losing everything** from market risk (do any trajectories go to $0.00 net worth)?  How is the distribution affected by the 'Investment Rate' decision?
        """)
        

    cols = st.columns(2)
    with cols[0]:
        plot = st.plotly_chart(ss.fig, use_container_width=True)

    # cols = st.columns(2)
    with cols[1]:
        stoch_plot = st.plotly_chart(ss.stoch_fig, use_container_width=True)
        

    cols = st.columns(2)
    with cols[0]:
        st.subheader('Unemployment Resilience')
        st.markdown("""
        The Unemployment Resilience chart shows how a household will fare with no wage/salary income.  How long **can the household remain debt free** after losing the income source?  By how much **does this time increase** with every year worked?  For very high net worth households, these trajectories may still **trend upwards** as assets returns can cover living expenses and some.
        """)
    with cols[1]:
        st.subheader('Resilience to Unexpected Life Events')
        st.markdown("""
        Unexpected life events (e.g. a death in the family, large one-time medical costs, ...) can be very financially damaging for a household.  Without a sufficient **cash/assets cushion** to pay for large expenses, some households must use short-term and/or high interest debt.  How is the households net worth affected by the expense?  Does the **timing** matter ("Year of Life Event Occurence" parameter)?  Is the situation **recoverable** or does it result in a **debt spiral**?
        """)

    cols = st.columns(2)
    with cols[0]:
        unemps_plot = st.plotly_chart(ss.unemps_fig, use_container_width=True)
    with cols[1]:
        events_plot = st.plotly_chart(ss.events_fig, use_container_width=True)



## Content Start

if tabs == 'Dashboard':
    st.header("Explore the Median Household's Outcomes")
    st.caption('Toggle the dropdown selectors and inputs below to explore different demographic profiles and starting year.')




if tabs == 'Comparison':
    st.header('Comparing the Demographic Profiles')

    st.markdown("""
            Insert intro to comparison here.
            """)

if tabs != 'Model Description':
    cols = st.columns(6)

if tabs == 'Dashboard':

    with cols[0]:
        homeowner = st.selectbox('Homeowner?', [(0, 1), (1, 5)], format_func=lambda _: ['Homeowner', 'Renter'][_[0]], key='homeowner')
    with cols[1]:
        education = st.selectbox('Education Level', [(0, 12), (1, 16), ], format_func=lambda _: ['High School', 'College Degree', ][_[0]], key='edu')
    with cols[2]:
        race = st.selectbox('Race', [(0, 2), (1, 1)], format_func=lambda _: ['Black', 'White', ][_[0]], key='race')

if tabs != 'Model Description':
    with cols[-2]:
        year = st.number_input('Starting Year (PSID Data)', 1999, 2019, step=2, key='year')



if tabs == 'Comparison':

    # cols = st.columns(6)
    with cols[-1]:
        st.caption('.')
        st.button('Reset Assumptions', on_click=reset_params)

    # cols = st.columns([1, 5, 1, 1])
    # with cols[-2]:
    #     year = st.number_input('Year', 1999, 2019, step=2, value=2019, key='year')

    ss.trajs = []
    # with cols
    # with cols[1]:
    #     opts = [(i, j, k, r, home, edu )  for i, home in [(0, 1), (1, 5)] for j, edu in [(0, 12), (1, 16)] for k, r in [(0, 2), (1, 1)]]
    #     scns = st.multiselect('Select', opts, 
    #     default = opts,
    #     format_func=lambda _: ['Black ', 'White ', ][_[2]] + ['HS ', 'B.A. ', ][_[1]] + ['HMWNR', 'RNTR'][_[0]] )
        
    # map = lambda _: ['Black ', 'White ', ][_[2]] + ['HS ', 'B.A. ', ][_[1]] + ['HMWNR', 'RNTR'][_[0]]
    scns = [(i, j, k, r, home, edu )  for k, r in [(0, 2), (1, 1)] for i, home in [(0, 1), (1, 5)] for j, edu in [(0, 12), (1, 16)] ]
    
    # scns = [map(i) for i in scns]
    # st.write(scns)
    comps = []
    labels = []
    fig = go.Figure()
    fig.update_layout(template='simple_white',  yaxis_title="Dollars ($)")
    fig.update_layout(height=550,)
    for item in scns:
        p = copy.copy(ss.user_params)
        for k, v in dict(data.loc[ss.year, item[3], item[4], item[5]]).items():
            if k not in ['I', 't', 'NW']:
                p[k] = v
            elif k == 'I' :
                p['I0'] = v

        # st.write(p)
        df, x = run_sim(p)
        label = ['Black ', 'White ', ][item[2]] + ['HS ', 'College Degree ', ][item[1]] + ['Homeowner', 'Renter'][item[0]]
        labels.append(label[6:])
        linedict = dict(color=['#D81B60', '#1E88E5'][item[2]], width=[2, 4][item[1]])
        if not item[0]: 
            linedict['dash']='dash'
        fig.add_trace(go.Scatter(x=df.t, y=(df.C+df.A+df.V)-(df.D+df.L),
                            line = linedict,
                            mode='lines',
                            name=label, legendrank=1))
        comps.append(np.asarray((df.C+df.A+df.V)-(df.D+df.L)))

    cols = st.columns([1, 8, 1])
    with cols[1]:
        st.caption("This chart compares the projected the Net Worth of each profile, carrying forward the assumptions, controls, and scenario set on the dashboard page.  Modify them in the dashboard to see how scenarios affect the racial wealth gap differently, and use the 'Reset Assumptions' button to reset to defaults.  Toggle lines on and off by clicking the corresponding label in the legend.")
        st.plotly_chart(fig, use_container_width=True)


    cols = st.columns(2)


    with cols[0]:
        st.markdown("""
            Explanation of ratio gap, very intense starting out, and generally decreases over time, seems to plateau eventually.
            """)



    with cols[1]:
        st.markdown("""
            Explanation of difference gap, very intense starting out, gets worse over time.
            """)

    cols = st.columns(2)

    fig = go.Figure()
    fig.update_layout(template='simple_white',  yaxis_title="Ratio: Black Net Worth / White Net Worth")
    for i, traj in enumerate(comps[:4]):
        # if i % 2 ==0:
        fig.add_trace(go.Scatter(x=df.t, y=np.divide(traj, comps[i+4]),
                        mode='lines',
                        name=labels[i], line=dict( width=4), legendrank=1))

    with cols[0]:
        st.plotly_chart(fig, use_container_width=True)

    fig = go.Figure()
    fig.update_layout(template='simple_white',  yaxis_title="Dollars ($)")
    for i, traj in enumerate(comps):
        if i % 2 ==0:
            fig.add_trace(go.Scatter(x=df.t, y=np.subtract(traj, comps[i+1]),
                            mode='lines',
                            name=labels[i], line=dict( width=4), legendrank=1))
    with cols[1]:
        st.plotly_chart(fig, use_container_width=True)


if tabs == 'Dashboard':
        

    
        

    for k, v in dict(data.loc[year, race[1], homeowner[1], education[1]]).items():
        ss['parameters'][k] = v


    with st.expander('Click here to play with the parameters and assumptions.'):
        layout_params()
    run_sim(ss.user_params)
    run_sensitivity(ss.user_params)
    plots()

if tabs == 'Model Description':

    st.header('Household Finance MiniModel')
    st.markdown("""
    We propose a simple model to capture household finance dynamics without too many degrees of freedom (variables).  The model simplifies a household's finances to four accounts which capture the different dynamics that determine net worth over time. 
        """)
    cols = st.columns([1, 3, 1])

    with cols[1]:
        st.image('./src/assets/accounts.png')
    st.markdown("""
        - Cash functions like cash and/or a checking account; it does not produce an annual return but can be used for expenses or paying down debt/interest
        - Asset(s) produce annual return (__rA__), these returns can be reinvested or taken to cash
        - Loan(s) take the place of a mortgage or business financing; have a low interest rate (__rL__) in most cases
        - Debt(s) takes the place of a credit card debt, payday lending, medical debt, etc.; have very high interest rates (__rD__) in most cases  
            """)
    
    st.markdown("""
    These four accounts change based on annual parameters (income, expenses), interest rates, and scenarios (unemployment, life events, policy proposals, etc.) according to the model flow.
    """)

    

    st.subheader('Model Flow')
    cols = st.columns([1.3, 1])
    with cols[0]:
        st.markdown("""
    Deterministic model projects forward based on initial conditions and control variables.')
    """)
    
        st.markdown("""
        - **Step 1:** Income is matched with expenses to see if there is excess income.  If expenses are in excess of income, and there is no Cash to spend or assets to exit, the household must borrow high-interest Debt(s) to cover the costs.
        - **Step 2:** Pay interest on Debt(s), and if Cash covers total interest expense (__rD__ x **D**) then pay down any high interest Debt(s).
        - **Step 3:** Pay interest on Loan(s), and if Cash covers total interest expense (__rL__ x **L**) then pay down up to 10% of outstanding Loan(s).
        - **Step 4:** Use remaining cash to invest in Asset(s), mark up assets with appreciation ((1 + __rA__) x **A**).
        """
    )
    with cols[-1]:
        st.image('./src/assets/model_structure.png')
        # st.caption('Visualization of Model Flow')


    # cols = st.columns(2)
    # with cols[0]:
    #     - – if not, Household must borrow to cover spending gap
    #     - Cash is allocated to paying back debt and loan, as well as investing
    # - Deterministic model projects forward based on initial conditions and control variables

    # """)

    
    st.subheader('Mapping to PSID Data')
    st.markdown('When initializing the model on PSID data, we map the following columns to the corresponding account.')
    st.markdown("""
    - Assets = Home Value + Farm/Business Value + CDS/Bonds Value + Real Estate Value + Stocks Value + IRA/Annuity Value + Other Assets
    - Cash = Checking/Savings Value
    - Loan = (Home Value – Home Equity Value) + Farm/Business Debt + Other Real Estate Debt
    - Debt = Credit Card Debt + Student Loan Debt + Legal Debt + Family Loan Debt + Other Debt

    """, unsafe_allow_html=True)
    st.caption('Vehicle value is not included in simulation variables, but is included in net worth calculation.')






    # cols = st.columns(2)
    # with cols[0]:
    #     st.subheader('Stochasticity')

    #     st.markdown("""
    # Returns – random sample
    # Life events
    # Medical bills
    # Measure resilience to a large one-time expense
    # Unemployment
    # Expenses stay the same, income = 0, how long till net worth hits 0?
    # """, unsafe_allow_html=True)

    # with cols[1]:
    #     st.subheader('Expenses')

    #     st.markdown("""
    # Looking at expenses by income, the median household needs at least ~$15,000/year regardless of income, and spends ~30% of every dollar above that.
    # """, unsafe_allow_html=True)
    #     st.image('./src/assets/expenses.png')
st.markdown('<hr>', unsafe_allow_html=True)
st.header('Acknowledgment')
st.text("INSERT ABOUT SJP and TEAM")

st.header('Purpose')
st.markdown(
    """

    This model was designed to simulate the effects of fiscal policy on household finances at the level of an individual or household inplace of aggregate statistics.  It can be used to inform fiscal policy design (e.g. tax incentives/policies, stimulus, UBI, baby bonds) by extending the model to the requisite level of granularity (asset and liability subclasses, discretionary v.s. non-discretionary spending).  By running the model with local/regional data, we can ask questions: Does policy result in its **intended effect**? What are the **side effects**? Does it **exacerbate or reduce** wealth inequality? 
    

    Additionally, it is important to the take the model out of the hands of the modeler and analyst in order to crowd-source model exploration and verification of the results/conculusions referenced by policy-makers.

    """
)



cols = st.columns(12)
with cols[0]:
    st.markdown("<br><br><br>", unsafe_allow_html=True)
    st.image('./src/assets/ORmadillo.jpg')
st.markdown("[MAIC](https://mitre.sharepoint.com/sites/L140)'ed by the [L141 ORmadillos](https://mitre.sharepoint.com/sites/ormadillos)")


streamlit_analytics.stop_tracking()

#    
#    
#    
#    
#    
#    
#    
#    
#    
#    
    # st.write(ss.df)

    # if ss.mode == 'comparison':





    # st.header('Bring Back to Data')


    # cols = st.columns(2)
    # with cols[0]:
    #     st.markdown("""
    #         The portfolio of assets and liabilities an individual has influences what drives their wealth. In general, the big movers of wealth tend to be home equity, investment accounts, retirement accounts, business value. For homeowners, home equity is key to their overall wealth. For the average homeowner, their home equity is the biggest contributor to changes in their wealth. Homeowners work to pay off their mortgages every month and these payments increase the equity of their home.  For those who invest, their retirement and investment accounts are major factors of wealth that are subject to market fluctuations and returns. Over the long run, the market has positive returns implying these accounts positively effect wealth. Retirement accounts serve as savings to subsist off in the long term. Stock investment accounts also can serve as savings for the future and/or a way to make additional income. An advantage of these accounts is compounded growth. If year to year returns are positive then the value of these accounts don’t grow linearly with time but exponentially. Business ownership and the value of those businesses are also a key factor of wealth. Business value represents wealth that can be passed on or bring income to other family members. Business owners also may spend a large portion of their time/resources on their businesses suggesting their business value to be the primary driver of their wealth. While business ownership/value, homeownership/ home value, and investments represent major factors of changing wealth, they also represent different archetypes. Going from not owning a home to owning a home will shift what assets and liabilities play a role into changing wealth and similarly, choosing to invest or not will indicate whether someone has the surplus cash/employment benefits to do so, suggesting different drivers of wealth as well.  
    #         """)

    # with cols[1]:
    #     st.image('./src/assets/homeowners.png')
    #     st.image('./src/assets/investors.png')
    #     st.image('./src/assets/business.png')



    # st.header('Bring Back to Data and Conclusion')

    # st.markdown("""
    #     Can talk about how homeownership is one of the biggest characteristics in determining what’s important for wealth and then introduce the slider for home value and appreciation rate. 

    #     For Homeowners retirement accs, business value, stocks, real estate, and vehicle value 	are most important. 

    #     Follow up with investing being important and introducing sliders for investment 

    #     portfolio/expected return. 

    #     For investors retirement accs, business value, stocks, real estate, are most important. 

    #     Then lastly introduce business ownership being important and the slider for business value. 

    #     Business is by far the most important.  

    #     Following those general archetypes, we can talk about those race specific factors. How Black people are more likely to be laden with student debt but no degree (citing additional external sources to verify) and how they are less likely to invest in retirement accounts which are advantaged by employer matching.  
            
    #         """)
